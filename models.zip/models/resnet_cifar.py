"""
CIFAR-style ResNet (He et al., 2016), 6n+2 layers, with every convolution
implemented as PrototypeConv2d so that the geometric-prototype-dictionary
compression of the paper is built into the network's parameterization from
the start, rather than applied to a separately pre-trained checkpoint.

Because the compiled layer of Section 0.4 preserves each convolution's
output shape and channel ordering exactly (Section 0.4.3: "identical in
shape and channel ordering to the output a standard, uncompiled convolution
would produce"), no architectural change is needed to accommodate pruning:
every conv layer -- including the two convs inside a residual block and the
1x1 shortcut/downsample convs -- can be replaced by PrototypeConv2d without
touching the residual-addition logic. This is a direct structural
consequence of the paper's method and is what lets the same BasicBlock code
used for a standard ResNet be reused here unchanged.
"""
import torch.nn as nn

from pruning.proto_conv2d import PrototypeConv2d


def _make_conv(in_planes, out_planes, kernel_size, stride, padding, bias, proto_kwargs):
    """
    Builds either a PrototypeConv2d (default) or a plain nn.Conv2d, selected
    via proto_kwargs["use_proto"] (default True). Plain conv is provided
    only for ablation / sanity-check purposes (e.g. verifying the standard
    architecture trains normally); the method under study is the proto path.
    """
    proto_kwargs = dict(proto_kwargs or {})
    use_proto = proto_kwargs.pop("use_proto", True)
    if use_proto:
        return PrototypeConv2d(
            in_planes, out_planes, kernel_size,
            stride=stride, padding=padding, bias=bias,
            **proto_kwargs,
        )
    return nn.Conv2d(
        in_planes, out_planes, kernel_size,
        stride=stride, padding=padding, bias=bias,
    )


def conv3x3(in_planes, out_planes, stride=1, proto_kwargs=None):
    return _make_conv(in_planes, out_planes, 3, stride, 1, False, proto_kwargs)


def conv1x1(in_planes, out_planes, stride=1, proto_kwargs=None):
    return _make_conv(in_planes, out_planes, 1, stride, 0, False, proto_kwargs)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes, planes, stride=1, proto_kwargs=None):
        super().__init__()
        self.conv1 = conv3x3(in_planes, planes, stride, proto_kwargs)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = conv3x3(planes, planes, 1, proto_kwargs)
        self.bn2 = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)

        self.downsample = None
        if stride != 1 or in_planes != planes * self.expansion:
            self.downsample = nn.Sequential(
                conv1x1(in_planes, planes * self.expansion, stride, proto_kwargs),
                nn.BatchNorm2d(planes * self.expansion),
            )

    def forward(self, x):
        identity = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        if self.downsample is not None:
            identity = self.downsample(x)
        out = out + identity
        return self.relu(out)


class ResNetCIFAR(nn.Module):
    def __init__(self, num_blocks_per_stage, num_classes=10, proto_kwargs=None):
        super().__init__()
        self.in_planes = 16
        self.conv1 = conv3x3(3, 16, 1, proto_kwargs)
        self.bn1 = nn.BatchNorm2d(16)
        self.relu = nn.ReLU(inplace=True)

        self.layer1 = self._make_layer(16, num_blocks_per_stage, stride=1, proto_kwargs=proto_kwargs)
        self.layer2 = self._make_layer(32, num_blocks_per_stage, stride=2, proto_kwargs=proto_kwargs)
        self.layer3 = self._make_layer(64, num_blocks_per_stage, stride=2, proto_kwargs=proto_kwargs)

        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(64 * BasicBlock.expansion, num_classes)

        self._init_weights()

    def _make_layer(self, planes, num_blocks, stride, proto_kwargs):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for s in strides:
            layers.append(BasicBlock(self.in_planes, planes, s, proto_kwargs))
            self.in_planes = planes * BasicBlock.expansion
        return nn.Sequential(*layers)

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1.0)
                nn.init.constant_(m.bias, 0.0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0.0)

    def forward(self, x):
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.avgpool(x)
        x = x.flatten(1)
        return self.fc(x)


def _resnet_n(n, num_classes=10, proto_kwargs=None):
    # 6n + 2 total weight layers.
    return ResNetCIFAR(num_blocks_per_stage=n, num_classes=num_classes, proto_kwargs=proto_kwargs)


def resnet20_cifar(num_classes=10, proto_kwargs=None):
    return _resnet_n(3, num_classes, proto_kwargs)


def resnet32_cifar(num_classes=10, proto_kwargs=None):
    return _resnet_n(5, num_classes, proto_kwargs)


def resnet44_cifar(num_classes=10, proto_kwargs=None):
    return _resnet_n(7, num_classes, proto_kwargs)


def resnet56_cifar(num_classes=10, proto_kwargs=None):
    return _resnet_n(9, num_classes, proto_kwargs)


def resnet110_cifar(num_classes=10, proto_kwargs=None):
    return _resnet_n(18, num_classes, proto_kwargs)
