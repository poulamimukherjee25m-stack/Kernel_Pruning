"""
Bottleneck ResNet-50 (He et al., 2016), every convolution implemented as
PrototypeConv2d, intended primarily for Tiny-ImageNet-200 (64x64 images, 200
classes) but usable for standard ImageNet-sized input too via `stem`.

As in models/resnet_cifar.py, the compiled layer of Section 0.4 preserves
each convolution's output shape and channel ordering exactly, so every conv
in a Bottleneck block -- the two 1x1's, the 3x3, and the 1x1 downsample
shortcut -- can be a PrototypeConv2d without any special-casing for the
residual addition.

Two stems are provided:
  * "imagenet": the standard 7x7 stride-2 conv + 3x3 stride-2 maxpool stem
    (matches torchvision's ResNet-50 for 224x224 input).
  * "tiny": a 3x3 stride-1 conv with no initial maxpool, which is the
    standard adjustment used for Tiny-ImageNet's 64x64 images -- the
    "imagenet" stem would downsample 64x64 to a 2x2 feature map by the time
    it reaches the global average pool (64 -> 32 -> 16 -> 16 -> 8 -> 4 -> 2),
    discarding most spatial structure before the network has done any
    representation learning at all. `resnet50_tiny_imagenet` defaults to
    this stem.
"""
import torch.nn as nn

from pruning.proto_conv2d import PrototypeConv2d


def _make_conv(in_planes, out_planes, kernel_size, stride, padding, bias, proto_kwargs):
    proto_kwargs = dict(proto_kwargs or {})
    use_proto = proto_kwargs.pop("use_proto", True)
    if use_proto:
        return PrototypeConv2d(
            in_planes, out_planes, kernel_size,
            stride=stride, padding=padding, bias=bias,
            **proto_kwargs,
        )
    return nn.Conv2d(in_planes, out_planes, kernel_size, stride=stride, padding=padding, bias=bias)


def conv3x3(in_planes, out_planes, stride=1, proto_kwargs=None):
    return _make_conv(in_planes, out_planes, 3, stride, 1, False, proto_kwargs)


def conv1x1(in_planes, out_planes, stride=1, proto_kwargs=None):
    return _make_conv(in_planes, out_planes, 1, stride, 0, False, proto_kwargs)


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, in_planes, planes, stride=1, proto_kwargs=None):
        super().__init__()
        self.conv1 = conv1x1(in_planes, planes, 1, proto_kwargs)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = conv3x3(planes, planes, stride, proto_kwargs)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = conv1x1(planes, planes * self.expansion, 1, proto_kwargs)
        self.bn3 = nn.BatchNorm2d(planes * self.expansion)
        self.relu = nn.ReLU(inplace=True)

        self.downsample = None
        if stride != 1 or in_planes != planes * self.expansion:
            self.downsample = nn.Sequential(
                conv1x1(in_planes, planes * self.expansion, stride, proto_kwargs),
                nn.BatchNorm2d(planes * self.expansion),
            )

    def forward(self, x):
        identity = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        if self.downsample is not None:
            identity = self.downsample(x)
        out = out + identity
        return self.relu(out)


class ResNetImageNet(nn.Module):
    def __init__(self, layers, num_classes=200, stem="tiny", proto_kwargs=None):
        super().__init__()
        if stem not in ("tiny", "imagenet"):
            raise ValueError("stem must be 'tiny' or 'imagenet'")
        self.in_planes = 64

        if stem == "imagenet":
            self.stem = nn.Sequential(
                _make_conv(3, 64, 7, 2, 3, False, proto_kwargs),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=3, stride=2, padding=1),
            )
        else:  # "tiny": no aggressive early downsampling (see module docstring)
            self.stem = nn.Sequential(
                conv3x3(3, 64, 1, proto_kwargs),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
            )

        self.layer1 = self._make_layer(64, layers[0], stride=1, proto_kwargs=proto_kwargs)
        self.layer2 = self._make_layer(128, layers[1], stride=2, proto_kwargs=proto_kwargs)
        self.layer3 = self._make_layer(256, layers[2], stride=2, proto_kwargs=proto_kwargs)
        self.layer4 = self._make_layer(512, layers[3], stride=2, proto_kwargs=proto_kwargs)

        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(512 * Bottleneck.expansion, num_classes)

        self._init_weights()

    def _make_layer(self, planes, num_blocks, stride, proto_kwargs):
        strides = [stride] + [1] * (num_blocks - 1)
        blocks = []
        for s in strides:
            blocks.append(Bottleneck(self.in_planes, planes, s, proto_kwargs))
            self.in_planes = planes * Bottleneck.expansion
        return nn.Sequential(*blocks)

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1.0)
                nn.init.constant_(m.bias, 0.0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0.0)

    def forward(self, x):
        x = self.stem(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.avgpool(x)
        x = x.flatten(1)
        return self.fc(x)


def resnet50_imagenet(num_classes=1000, stem="imagenet", proto_kwargs=None):
    return ResNetImageNet([3, 4, 6, 3], num_classes=num_classes, stem=stem, proto_kwargs=proto_kwargs)


def resnet50_tiny_imagenet(num_classes=200, proto_kwargs=None):
    return ResNetImageNet([3, 4, 6, 3], num_classes=num_classes, stem="tiny", proto_kwargs=proto_kwargs)
