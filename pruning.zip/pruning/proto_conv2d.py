"""
PrototypeConv2d: a drop-in replacement for nn.Conv2d that implements the
geometric-prototype-dictionary reparameterization of the paper (Sections
0.1-0.2), trained jointly with the task through the unified rate-distortion
objective of Section 0.3 (Eq. 21).

Per layer, this module owns:

  * `weight`  -- the *unconstrained* filter bank W = {w_i}, w_i in R^d
                 (Section 0.1). This is an ordinary learnable conv weight
                 tensor; r_i = ||w_i||_2 and u_i = w_i / ||w_i||_2 (Eq. 1) are
                 derived from it on every forward call, never stored
                 separately.
  * `P_raw`   -- an over-complete dictionary of K learnable directions,
                 re-projected onto the unit hypersphere on every forward call
                 to give P = {p_1, ..., p_K} subset S^{d-1} (Eq. 2, Section
                 0.2.1).
  * `gate`    -- a HardConcreteGate holding the K usage logits eta_k that
                 realize the usage indicators z_k (Eq. 3, Section 0.2.3).
  * `tau`     -- the assignment temperature (Eq. 9-10), a *non-learnable*
                 scalar buffer set externally by a deterministic annealing
                 schedule (see pruning/schedules.py), exactly as prescribed
                 in Section 0.2.2 ("tau is increased monotonically according
                 to a predefined, deterministic annealing schedule").

Forward pass (training):
  1. Decompose W into (r_i, u_i)                                    (Eq. 1)
  2. Project P_raw onto S^{d-1}                                     (Sec 0.2.1)
  3. Sample usage z_k from the Hard-Concrete relaxation              (Eq. 12-13)
  4. Compute the usage-gated, temperature-scaled soft assignment a_i (Eq. 9)
  5. Reconstruct the direction as the re-projected convex combination
     u_hat_i = normalize(sum_k a_ik p_k)                             (Eq. 14)
  6. Reconstruct the operator  w_hat_i = r_i * u_hat_i                (Eq. 14)
  7. Convolve the input with W_hat and return that as the layer's
     output (this, not W, is what feeds L_task and every later layer --
     Section 0.3.2, "Only W_hat is used to compute L_task ... W receives
     gradient exclusively through the distortion term").

If `track_distortion` is enabled and the module is in training mode, the
same input is *also* convolved with the raw, unconstrained W, and the
per-layer functional-distortion numerator/denominator of Eq. 18-19 are
cached on the module (`_last_dist_num`, `_last_dist_den`) for the training
loop to aggregate into L_dist via `pruning.losses.distortion_loss`.
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from .hard_concrete import HardConcreteGate


def _pair(x):
    if isinstance(x, (tuple, list)):
        assert len(x) == 2
        return tuple(x)
    return (x, x)


class PrototypeConv2d(nn.Module):
    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        stride=1,
        padding=0,
        dilation=1,
        groups=1,
        bias=True,
        K=None,
        K_mult=0.5,
        K_min=4,
        tau_init=4.0,
        gate_beta=2.0 / 3.0,
        gate_gamma=-0.1,
        gate_zeta=1.1,
        gate_init_keep_prob=0.9,
        track_distortion=True,
        eps=1e-8,
    ):
        super().__init__()
        if groups != 1:
            # The paper's derivation (Sections 0.1, 0.4.2) is stated for a
            # single flattened filter space R^d = R^{c_in * k * k}; grouped
            # convolutions partition that space per group and are outside
            # the scope of this reference implementation. ResNet-56 for
            # CIFAR-10 does not require grouped convolutions.
            raise NotImplementedError("PrototypeConv2d currently supports groups=1 only.")

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = _pair(kernel_size)
        self.stride = _pair(stride)
        self.padding = _pair(padding)
        self.dilation = _pair(dilation)
        self.groups = groups
        self.eps = eps
        self.track_distortion = track_distortion

        self.d = in_channels * self.kernel_size[0] * self.kernel_size[1]

        if K is None:
            K = max(K_min, int(round(out_channels * K_mult)))
        self.K = K

        # --- Unconstrained filter bank W = {w_i}, w_i in R^d (Section 0.1) ---
        self.weight = nn.Parameter(torch.empty(out_channels, in_channels, *self.kernel_size))
        nn.init.kaiming_normal_(self.weight, mode="fan_out", nonlinearity="relu")

        if bias:
            self.bias = nn.Parameter(torch.zeros(out_channels))
        else:
            self.register_parameter("bias", None)

        # --- Over-complete geometric prototype dictionary P (Eq. 2) ---
        # Stored unnormalized; re-projected onto S^{d-1} on every forward
        # call so gradients flow through the projection itself.
        self.P_raw = nn.Parameter(torch.randn(K, self.d) / math.sqrt(self.d))

        # --- Prototype usage indicators z_k (Eq. 3, Section 0.2.3) ---
        self.gate = HardConcreteGate(
            K, beta=gate_beta, gamma=gate_gamma, zeta=gate_zeta, init_keep_prob=gate_init_keep_prob
        )

        # --- Assignment temperature tau (Eq. 9), externally annealed ---
        self.register_buffer("tau", torch.tensor(float(tau_init)))

        # Diagnostics populated on the most recent forward call.
        self._last_dist_num = None
        self._last_dist_den = None
        self._last_assignment_margin = None  # mean delta_i (Eq. 11), logging only

    def set_tau(self, value: float):
        self.tau.fill_(float(value))

    # ------------------------------------------------------------------ #
    # Core geometric machinery
    # ------------------------------------------------------------------ #
    def _decompose(self):
        """Polar decomposition w_i = r_i * u_i (Eq. 1)."""
        W_flat = self.weight.view(self.out_channels, -1)  # (C_out, d)
        r = W_flat.norm(dim=1, keepdim=True).clamp_min(self.eps)  # (C_out, 1)
        u = W_flat / r
        return W_flat, r, u

    def _dictionary(self):
        """Project the learnable dictionary onto S^{d-1} (Section 0.2.1)."""
        norm = self.P_raw.norm(dim=1, keepdim=True).clamp_min(self.eps)
        return self.P_raw / norm  # (K, d)

    def reconstruct(self, return_diagnostics=False):
        """
        Builds the reconstructed operator W_hat via Eqs. 9 and 14, and
        returns it alongside the flattened raw weight (for the distortion
        term) and, optionally, the assignment/usage tensors for logging.
        """
        W_flat, r, u = self._decompose()
        P = self._dictionary()
        z = self.gate()  # (K,) -- sampled during training, hard() at eval

        # Usage-gated, temperature-scaled softmax assignment (Eq. 9).
        # Numerical note: at large tau (late in the annealing schedule) the
        # raw logits tau*<u_i,p_k> can overflow exp() long before the
        # subsequent multiplication by z_k would have zeroed them out for a
        # usage-gated-off prototype (0 * exp(huge) = nan, not 0). We
        # therefore mask logits at inactive (z_k == 0) prototypes to -inf
        # *before* the softmax max-shift and exponential, so the shift is
        # taken only over currently-active prototypes and inactive columns
        # contribute an exact, finite zero.
        cos = u @ P.t()  # (C_out, K), directional agreement <u_i, p_k>
        logits = self.tau * cos
        z_row = z.unsqueeze(0).expand_as(logits)
        active = z_row > 0
        neg_inf = torch.finfo(logits.dtype).min
        masked_logits = torch.where(active, logits, torch.full_like(logits, neg_inf))
        logits_max = masked_logits.max(dim=1, keepdim=True).values.detach()
        # A row can only be all-inactive if every z_k in the layer is zero,
        # which forward() never reaches (Eq. 9 requires sum_j z_j > 0); guard
        # anyway so this never silently produces NaNs.
        logits_max = torch.where(torch.isfinite(logits_max), logits_max, torch.zeros_like(logits_max))
        exp_logits = torch.exp((masked_logits - logits_max).clamp_min(-80.0))
        weighted = z_row * exp_logits  # (C_out, K); exactly 0 at inactive columns
        denom = weighted.sum(dim=1, keepdim=True).clamp_min(self.eps)
        a = weighted / denom  # (C_out, K), rows on the simplex Delta^{K-1}

        # Reconstructed direction: re-projected convex combination (Eq. 14).
        u_hat_raw = a @ P  # (C_out, d)
        u_hat_norm = u_hat_raw.norm(dim=1, keepdim=True).clamp_min(self.eps)
        u_hat = u_hat_raw / u_hat_norm

        W_hat_flat = r * u_hat  # (C_out, d)
        W_hat = W_hat_flat.view_as(self.weight)

        if return_diagnostics:
            with torch.no_grad():
                margin = 1.0 - a.max(dim=1).values  # delta_i (Eq. 11)
            return W_hat, W_flat, {"a": a, "z": z, "margin": margin}
        return W_hat, W_flat

    # ------------------------------------------------------------------ #
    def forward(self, x):
        W_hat, W_flat = self.reconstruct()
        y_hat = F.conv2d(
            x, W_hat, self.bias, self.stride, self.padding, self.dilation, self.groups
        )

        if self.training and self.track_distortion:
            # F_l(x; W) vs F_l(x; W_hat) at this layer, with every other
            # layer's weights held fixed (Eq. 18); W receives gradient only
            # through this term (Section 0.3.2).
            W_orig = W_flat.view_as(self.weight)
            y_orig = F.conv2d(
                x, W_orig, self.bias, self.stride, self.padding, self.dilation, self.groups
            )
            self._last_dist_num = (y_hat - y_orig).pow(2).sum()
            self._last_dist_den = y_orig.pow(2).sum().clamp_min(self.eps)
        else:
            self._last_dist_num = None
            self._last_dist_den = None

        return y_hat

    # ------------------------------------------------------------------ #
    # Convenience accessors used by the training loop / logging
    # ------------------------------------------------------------------ #
    def expected_cardinality(self):
        """sum_k E[z_k] for this layer's contribution to R(K_eff) (Eq. 20)."""
        return self.gate.expected().sum()

    def hard_effective_cardinality(self, threshold=0.5):
        with torch.no_grad():
            return int((self.gate.hard() > threshold).sum().item())

    def extra_repr(self):
        return (
            f"in_channels={self.in_channels}, out_channels={self.out_channels}, "
            f"kernel_size={self.kernel_size}, stride={self.stride}, padding={self.padding}, "
            f"K={self.K}, d={self.d}"
        )
