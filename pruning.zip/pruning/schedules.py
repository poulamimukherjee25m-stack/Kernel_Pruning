"""
Deterministic schedules used by the training loop.

`anneal_tau` implements the "predefined, deterministic annealing schedule"
for the assignment temperature tau required by Section 0.2.2: tau starts low
(spreading assignment mass across every active prototype, easing early
optimization before directions/dictionary have organized) and increases
monotonically so that, in the tau -> infinity limit, the soft assignment of
Eq. 9 recovers the hard, one-hot assignment of Eq. 5 (Eq. 10). We anneal it
geometrically (linear in log-space) for a smooth increase across many orders
of magnitude.

`linear_warmup` is a training-procedure convenience (not part of Eq. 21
itself) for ramping lambda_1/lambda_2 up from 0 over the first few epochs, so
the task loss has a chance to organize the representation before the
distortion/cardinality terms begin exerting pressure. Using it is optional;
setting warmup_steps=0 disables it (constant target value throughout).
"""
import math


def anneal_tau(step, total_steps, tau_start=4.0, tau_end=60.0, warmup_frac=0.1):
    if total_steps <= 0:
        return tau_end
    warmup_steps = int(warmup_frac * total_steps)
    if step <= warmup_steps:
        return tau_start
    progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
    progress = min(max(progress, 0.0), 1.0)
    log_tau = math.log(tau_start) + progress * (math.log(tau_end) - math.log(tau_start))
    return math.exp(log_tau)


def linear_warmup(step, warmup_steps, target):
    if warmup_steps <= 0:
        return target
    frac = min(1.0, step / warmup_steps)
    return target * frac
