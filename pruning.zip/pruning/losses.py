"""
Aggregation of the per-layer quantities produced by PrototypeConv2d into the
three terms of the unified rate-distortion objective (Eq. 21):

    L = L_task(W_hat) + lambda_1 * L_dist + lambda_2 * R(K_eff)

L_task is ordinary cross-entropy on the network's own forward pass (which
already uses every layer's W_hat, per Section 0.3.2) and is computed by the
training loop directly; this module supplies L_dist (Eq. 19) and R(K_eff)
(Eq. 20) by walking the model for PrototypeConv2d submodules.
"""
import torch
import torch.nn as nn

from .proto_conv2d import PrototypeConv2d


def prototype_modules(model: nn.Module):
    return [m for m in model.modules() if isinstance(m, PrototypeConv2d)]


def set_model_tau(model: nn.Module, tau: float):
    """Applies the externally-computed annealing schedule value to every
    prototype-conv layer (Section 0.2.2: tau is a single global schedule)."""
    for m in prototype_modules(model):
        m.set_tau(tau)


def _zero(model):
    device = next(model.parameters()).device
    return torch.zeros((), device=device)


def distortion_loss(model: nn.Module):
    """
    L_dist = sum_l  E_x[||F_l(x;W) - F_l(x;W_hat)||^2] / E_x[||F_l(x;W)||^2]   (Eq. 19)

    Uses the per-layer numerator/denominator cached by each PrototypeConv2d
    on its most recent forward call (only populated in training mode with
    track_distortion=True).
    """
    terms = []
    for m in prototype_modules(model):
        if m._last_dist_num is not None:
            terms.append(m._last_dist_num / m._last_dist_den)
    if not terms:
        return _zero(model)
    return torch.stack(terms).sum()


def cardinality_reg(model: nn.Module):
    """R(K_eff) = sum_l sum_k E[z_k^(l)]   (Eq. 20)."""
    terms = [m.expected_cardinality() for m in prototype_modules(model)]
    if not terms:
        return _zero(model)
    return torch.stack(terms).sum()


def effective_cardinality_report(model: nn.Module, threshold: float = 0.5):
    """
    Per-layer (K, K_eff) snapshot using the deterministic, noise-free gate
    (Section 0.2.3), i.e. what `compile_model` would realize right now.
    Returns (report_list, total_K_eff, total_C_out).
    """
    report = []
    total_k_eff, total_c = 0, 0
    for idx, m in enumerate(prototype_modules(model)):
        k_eff = m.hard_effective_cardinality(threshold=threshold)
        report.append({"layer": idx, "C_out": m.out_channels, "K": m.K, "K_eff": k_eff})
        total_k_eff += k_eff
        total_c += m.out_channels
    return report, total_k_eff, total_c
