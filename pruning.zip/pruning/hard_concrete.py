"""
Hard-Concrete usage gate, implementing the prototype-usage relaxation of
Section 0.2.3 (Eqs. 12-13) of the paper.

    s_k        = sigmoid( (log u - log(1-u) + eta_k) / beta ),   u ~ U(0,1)      (Eq. 12)
    s_bar_k    = s_k * (zeta - gamma) + gamma                                     (Eq. 13)
    z_k        = min(1, max(0, s_bar_k))                                          (Eq. 13)

`eta_k` is the *unconstrained learnable logit* the optimizer adjusts directly
(the paper is explicit that eta_k itself, not a logarithm of it, is what
training adjusts -- Section 0.2.3, discussion after Eq. 13). `beta` is a fixed
relaxation temperature and `(gamma, zeta)` are fixed stretching constants with
gamma < 0 < 1 < zeta, all independent of training.

Three views of the same gate are needed at different points in the pipeline:

  * `sample()`   -- the stochastic relaxation used during training (Eq. 12-13),
                    used to gate the assignment softmax of Eq. 9.
  * `expected()` -- a differentiable surrogate for E[z_k], used only inside the
                    cardinality/rate objective R(K_eff) = sum_k E[z_k] (Eq. 20).
                    This is the standard closed-form P(z_k > 0) surrogate for
                    the Hard-Concrete/L0 relaxation (Louizos, Welling & Kingma,
                    "Learning Sparse Neural Networks through L0 Regularization",
                    ICLR 2018), specialized to the paper's parameterization by
                    substituting log(alpha_k) -> eta_k.
  * `hard()`     -- the deterministic, noise-free gate value used at
                    evaluation time and by the structural compiler (Section
                    0.4), obtained by dropping the logistic noise term
                    (equivalently, evaluating Eq. 12 at its median u = 0.5):

                        z_hat_k = min(1, max(0, sigmoid(eta_k / beta) * (zeta - gamma) + gamma))

                    Thresholding z_hat_k at 1/2 recovers the idealized binary
                    usage indicator z_k in {0,1} of Section 0.1.
"""
import math

import torch
import torch.nn as nn


class HardConcreteGate(nn.Module):
    def __init__(self, size, beta=2.0 / 3.0, gamma=-0.1, zeta=1.1, init_keep_prob=0.9, eps=1e-6):
        super().__init__()
        if not (gamma < 0.0 < 1.0 < zeta):
            raise ValueError("Require gamma < 0 < 1 < zeta.")
        self.size = size
        self.beta = beta
        self.gamma = gamma
        self.zeta = zeta
        self.eps = eps

        # Initialize eta so that the *hard* (noise-free) gate starts close to
        # `init_keep_prob`, i.e. prototypes begin mostly "in use" and the
        # optimization is free to drive unnecessary ones to zero usage
        # (Section 0.2.3: "a prototype ... is discarded by the optimization
        # rather than by a separate decision rule applied to P after
        # training").
        target = (init_keep_prob - gamma) / (zeta - gamma)
        target = min(max(target, eps), 1 - eps)
        init_val = beta * math.log(target / (1 - target))
        self.eta = nn.Parameter(torch.full((size,), float(init_val)))

    def sample(self):
        """Stochastic Hard-Concrete relaxation of z_k (Eq. 12-13)."""
        u = torch.rand_like(self.eta).clamp_(self.eps, 1.0 - self.eps)
        s = torch.sigmoid((torch.log(u) - torch.log(1.0 - u) + self.eta) / self.beta)
        s_bar = s * (self.zeta - self.gamma) + self.gamma
        return s_bar.clamp(0.0, 1.0)

    def expected(self):
        """Differentiable surrogate for E[z_k], used in R(K_eff) (Eq. 20)."""
        return torch.sigmoid(self.eta - self.beta * math.log(-self.gamma / self.zeta))

    def hard(self):
        """Deterministic, noise-free gate value (Section 0.2.3, compiler input)."""
        s = torch.sigmoid(self.eta / self.beta)
        s_bar = s * (self.zeta - self.gamma) + self.gamma
        return s_bar.clamp(0.0, 1.0)

    def forward(self):
        return self.sample() if self.training else self.hard()
