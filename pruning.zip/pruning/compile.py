"""
Geometry-aware structural compiler (Section 0.4 of the paper).

At convergence, every surviving filter direction u_i is exactly a dictionary
prototype, u_hat_i = p_k(i) (Eq. 6). Because convolution is linear in its
filter argument, the i-th output channel is then a scalar multiple of a
quantity that depends on the input only through the shared prototype it was
assigned to (Eq. 22-23):

    Y_i = w_hat_i * X = (r_i p_k(i)) * X = r_i * (p_k(i) * X).

`compile_model` realizes this in executable form: for every surviving
prototype it computes a single *base convolution* B_k = p_k * X once
(Eq. 24), then reconstructs every original output channel as one scalar
multiplication B_{pi(i)} * r_i (Eq. 25), assembled back in the original
channel order (Eq. 22's output shape is preserved exactly, so compilation is
a drop-in replacement -- Section 0.4.3).

This is a deterministic, one-shot procedure applied *after* training: it
performs no optimization and introduces no new decision (Section 0.4.5).
Every quantity it needs (surviving prototypes K, the assignment index k(i),
and the magnitudes r_i) was already fixed by the training objective of
Section 0.3.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .proto_conv2d import PrototypeConv2d


class CompiledProtoConv2d(nn.Module):
    """
    Inference-only, compiled realization of a converged PrototypeConv2d
    layer. Computes K_eff base convolutions instead of C_out (Eq. 26-28)
    and stores K_eff*d + C_out (+ C_out for bias) parameters instead of
    C_out*d (Eq. 29), plus the O(C_out log2 K_eff)-bit index map.
    """

    def __init__(self, proto_conv: PrototypeConv2d, threshold: float = 0.5):
        super().__init__()
        with torch.no_grad():
            W_flat, r, u = proto_conv._decompose()
            P = proto_conv._dictionary()
            z_hard = proto_conv.gate.hard()

            active_mask = z_hard > threshold
            active_idx = active_mask.nonzero(as_tuple=True)[0]
            if active_idx.numel() == 0:
                # Degenerate case (e.g. an under-trained checkpoint): keep
                # the single best-used prototype so the layer stays valid,
                # rather than silently collapsing the layer to zero output.
                active_idx = z_hard.topk(1).indices

            P_active = P.index_select(0, active_idx)  # (K_eff, d)
            K_eff = P_active.shape[0]

            # Hardened assignment index k(i), restricted to surviving
            # prototypes only (Eq. 5), reproducing the tau -> infinity limit
            # of Eq. 9-10 exactly since P is already fixed post-training.
            cos_active = u @ P_active.t()  # (C_out, K_eff)
            index_map = cos_active.argmax(dim=1)  # (C_out,) in [0, K_eff)

            in_channels = proto_conv.in_channels
            kh, kw = proto_conv.kernel_size
            base_weight = P_active.view(K_eff, in_channels, kh, kw).clone()

        self.register_buffer("base_weight", base_weight)
        self.register_buffer("scale", r.view(-1).clone())  # (C_out,)
        self.register_buffer("index_map", index_map.clone())  # (C_out,)
        if proto_conv.bias is not None:
            self.register_buffer("bias", proto_conv.bias.detach().clone())
        else:
            self.bias = None

        self.in_channels = proto_conv.in_channels
        self.out_channels = proto_conv.out_channels
        self.kernel_size = proto_conv.kernel_size
        self.stride = proto_conv.stride
        self.padding = proto_conv.padding
        self.dilation = proto_conv.dilation
        self.groups = proto_conv.groups
        self.K_eff = K_eff
        self.K = proto_conv.K
        self.d = proto_conv.d

    def forward(self, x):
        # One convolution producing K_eff base feature maps B_k = p_k * X (Eq. 24).
        B = F.conv2d(x, self.base_weight, None, self.stride, self.padding, self.dilation, self.groups)
        # Per-channel reconstruction Y_i = r_i * B_{pi(i)} (Eq. 25), assembled
        # in the original channel order via index_select on dim=1.
        Y = B.index_select(1, self.index_map) * self.scale.view(1, -1, 1, 1)
        if self.bias is not None:
            Y = Y + self.bias.view(1, -1, 1, 1)
        return Y

    def flops(self, H, W):
        """Multiply-add count for one forward call, given output H x W (Eq. 27)."""
        base = self.K_eff * self.d * H * W
        recon = self.out_channels * H * W
        return base + recon

    def num_params(self):
        """Stored parameter count, excluding the O(C_out log2 K_eff)-bit index map (Eq. 29)."""
        p = self.K_eff * self.d + self.out_channels
        if self.bias is not None:
            p += self.out_channels
        return p

    def extra_repr(self):
        return (
            f"in_channels={self.in_channels}, out_channels={self.out_channels}, "
            f"kernel_size={self.kernel_size}, stride={self.stride}, padding={self.padding}, "
            f"K={self.K}, K_eff={self.K_eff}"
        )


def compile_model(model: nn.Module, threshold: float = 0.5) -> nn.Module:
    """
    Recursively replaces every PrototypeConv2d submodule of `model` with its
    compiled, inference-only CompiledProtoConv2d equivalent (Section 0.4).
    Mutates and returns `model`. The model should be in eval mode and its
    training considered converged before calling this.
    """
    for name, child in model.named_children():
        if isinstance(child, PrototypeConv2d):
            setattr(model, name, CompiledProtoConv2d(child, threshold=threshold))
        else:
            compile_model(child, threshold=threshold)
    return model


def profile_model(model: nn.Module, input_size=(1, 3, 32, 32), device="cpu"):
    """
    Forward-hook-based multiply-add and parameter-count profiler that
    understands nn.Conv2d, PrototypeConv2d (profiled at its *uncompiled*,
    dense cost -- C_out*d*H*W, Eq. 26) and CompiledProtoConv2d (profiled at
    its compiled cost, Eq. 27). Also accounts for the final nn.Linear head.
    Returns (total_flops, total_params).
    """
    model = model.to(device)
    totals = {"flops": 0, "params": 0}
    hooks = []

    def hook(module, inp, out):
        H, W = out.shape[-2], out.shape[-1]
        if isinstance(module, CompiledProtoConv2d):
            totals["flops"] += module.flops(H, W)
            totals["params"] += module.num_params()
        elif isinstance(module, PrototypeConv2d):
            f = module.out_channels * module.d * H * W
            p = module.out_channels * module.d
            if module.bias is not None:
                p += module.out_channels
            totals["flops"] += f
            totals["params"] += p
        elif isinstance(module, nn.Conv2d):
            d = (module.in_channels // module.groups) * module.kernel_size[0] * module.kernel_size[1]
            totals["flops"] += module.out_channels * d * H * W
            totals["params"] += sum(pp.numel() for pp in module.parameters())

    for m in model.modules():
        if isinstance(m, (nn.Conv2d, PrototypeConv2d, CompiledProtoConv2d)):
            hooks.append(m.register_forward_hook(hook))

    was_training = model.training
    model.eval()
    with torch.no_grad():
        model(torch.randn(*input_size, device=device))
    model.train(was_training)

    for h in hooks:
        h.remove()

    for m in model.modules():
        if isinstance(m, nn.Linear):
            totals["params"] += sum(pp.numel() for pp in m.parameters())
            totals["flops"] += m.in_features * m.out_features

    return totals["flops"], totals["params"]
